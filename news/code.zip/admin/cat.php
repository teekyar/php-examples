<?php require '../include/functions.php';
$r=$_REQUEST['get'];
$i=$_REQUEST['id'];
if($r=='' && $i==''){
$query=mysqli_query($conn,'SELECT * FROM `cat` WHERE `status`=1');
echo '<a href="cat.php?get=add">افزودن</a><ol>';
while($q=mysqli_fetch_array($query)){
echo '<li>'.$q['name'].'-<a href="cat.php?get=edit&id='.$q['id'].'">ویرایش</a>-<a href="cat.php?get=delete&id='.$q['id'].'">حذف</a></li>';
}
echo '</ol>';
}elseif($r=='edit' && $i!=''){
$q=mysqli_fetch_array(mysqli_query($conn,'SELECT * FROM `cat` WHERE `id`='.$i));
if($_POST['name']!=null){
if(mysqli_query($conn,"UPDATE `cat` SET `name` = '".$_POST['name']."' WHERE `cat`.`id` = 1;")){
    echo 'با موفقیت ویرایش شد.';
}else{
    echo 'مشکلی پیش آمد!';
}
echo '<br><a href="cat.php">بازگشت</a>';
} ?>
<form action="" method="post">
    <input type="text" name="name" placeholder="نام دسته بندی" value="<?php echo $q['name']; ?>"><br>
    <input type="submit" name="submit" value="ویرایش">
</form>
<?php }elseif($r=='delete' && $i!=''){
if(mysqli_query($conn,"UPDATE `cat` SET `status` = 'deleted' WHERE `cat`.`id` = ".$i.";")){
    echo 'با موفقیت حذف شد.';
}else{
    echo 'مشکلی پیش آمد!';
}
echo '<br><a href="cat.php">بازگشت</a>';
}elseif($r=='add' && $i==''){
if($_POST['name']!=null){
if(mysqli_query($conn,"INSERT INTO `cat` (`id`, `name`, `type`, `parent`, `by`, `date`, `uby`, `udate`, `status`) VALUES (NULL, '".$_POST['name']."', 'parent', '0', '1', '2022-04-06 12:21:33', '0', '0', 'active');")){
    echo 'افزوده شد.';
}else{
    echo 'مشکلی پیش آمد!';
}
echo '<br><a href="cat.php">بازگشت</a>';
} ?>
<form action="" method="post">
    <input type="text" name="name" placeholder="نام دسته بندی" value="<?php echo $q['name']; ?>"><br>
    <input type="submit" name="submit" value="افزودن">
</form>
<?php } ?>
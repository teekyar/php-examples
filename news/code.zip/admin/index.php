<?php require '../include/functions.php'; ?>
<center><a href="cat.php">مدیریت موضوعات</a>-<a href="news.php">مدیریت اخبار</a></center>
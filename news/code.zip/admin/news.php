<?php require '../include/functions.php';
$r=$_REQUEST['get'];
$i=$_REQUEST['id'];
if($r=='' && $i==''){
$query=mysqli_query($conn,'SELECT * FROM `news` WHERE `status`=1');
echo '<a href="news.php?get=add">افزودن</a><ol>';
while($q=mysqli_fetch_array($query)){
echo '<li>'.$q['name'].'-<a href="news.php?get=edit&id='.$q['id'].'">ویرایش</a>-<a href="news.php?get=delete&id='.$q['id'].'">حذف</a></li>';
}
echo '</ol>';
}elseif($r=='edit' && $i!=''){
$q=mysqli_fetch_array(mysqli_query($conn,'SELECT * FROM `news` WHERE `id`='.$i));
if($_POST['name']!=null){
if(mysqli_query($conn,"UPDATE `cat` SET `name` = '".$_POST['name']."' WHERE `cat`.`id` = 1;")){
    echo 'با موفقیت ویرایش شد.';
}else{
    echo 'مشکلی پیش آمد!';
}
echo '<br><a href="news.php">بازگشت</a>';
} ?>
<form action="" method="post">
    <input type="text" name="name" placeholder="نام دسته بندی" value="<?php echo $q['name']; ?>"><br>
    <input type="submit" name="submit" value="ویرایش">
</form>
<?php }elseif($r=='delete' && $i!=''){
if(mysqli_query($conn,"UPDATE `news` SET `status` = 'deleted' WHERE `news`.`id` = ".$i.";")){
    echo 'با موفقیت حذف شد.';
}else{
    echo 'مشکلی پیش آمد!';
}
echo '<br><a href="news.php">بازگشت</a>';
}elseif($r=='add' && $i==''){
if($_POST['name']!=null && $_POST['leader']!=null && $_POST['desc']!=null && $_POST['cat']!=null && $_POST['tags']!=null && $_POST['img']!=null && $_POST['type']!=null){
if(mysqli_query($conn,"INSERT INTO `news` (`id`, `name`, `leader`, `desc`, `catid`, `tags`, `image`, `hit`, `date`, `type`, `by`, `udate`, `uby`, `status`) VALUES (NULL, '".$_POST['name']."', '".$_POST['leader']."', '".$_POST['desc']."', '".$_POST['cat']."', '".$_POST['tags']."', '".$_POST['img']."', '0', CURRENT_TIMESTAMP, '".$_POST['type']."', '1', CURRENT_TIMESTAMP, '1', 'active');")){
    echo 'افزوده شد.';
}else{
    echo 'مشکلی پیش آمد!';
}
echo '<br><a href="news.php">بازگشت</a>';
} ?>
<form action="" method="post">
    <input type="text" name="name" placeholder="نام خبر"><br>
    <input type="text" name="leader" placeholder="خلاصه خبر"><br>
    <input type="text" name="desc" placeholder="توضیحات خبر"><br>
    <select name="cat">
        <?php $query=mysqli_query($conn,'SELECT * FROM `cat` WHERE `status`=1');
        while($q=mysqli_fetch_array($query)){
            echo '<option value="'.$q['id'].'">'.$q['name'].'</option>';
        } ?>
    </select>
    <input type="text" name="tags" placeholder="برچسب ها"><br>
    <input type="text" name="img" placeholder="آدرس تصویر"><br>
    <select name="type">
        <option value="rec">خبر پیشنهادی</option>
        <option value="selected">خبرانتخاب شده</option>
        <option value="req">خبر داغ</option>
        <option value="normal">خبر عادی</option>
    </select>
    <input type="submit" name="submit" value="افزودن">
</form>
<?php } ?>
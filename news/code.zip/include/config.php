<?php if(!defined('filesecurity')){header('Location: /');exit;}else{
    $dbh='localhost';
    $dbu='root';
    $dbp='root';
    $dbn='newws';
} ?>
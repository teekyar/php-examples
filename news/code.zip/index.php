<?php require './include/functions.php';
define('pactive', '');
//System
if (empty($_REQUEST['get']) AND empty($_REQUEST['p']) AND empty($_REQUEST['search'])) {
	$get = 'index';
	$p = null;
	$s = null;
} else {
	$get = str_replace(' ','',clean($_REQUEST['get']));
	$p = str_replace(' ','',clean($_REQUEST['p']));
	$s = null;
}
//Get Content
if ($get == 'index' AND $p == null) {
	$title = "صفحه اصلی";
	require './theme/header.php';
	require './system/index.php';
	require './theme/footer.php';
} elseif ($get == 'news' AND $p != null) {
	$pquery = mysqli_query($conn, "SELECT * FROM `news` WHERE `id`=$p AND `status`=1"); $pq = mysqli_fetch_array($pquery);
	if ($pq != null) {
		$title = $pq['name'];
	} else {
		$title = "404";
	}
	require './theme/header.php';
	if ($pq != null) {
		require './system/news.php';
	} else {
		require './system/404.php';
	}
	require './theme/footer.php';
} elseif ($get == 'cat' AND $p != null) {
	$pquery = mysqli_query($conn, "SELECT * FROM `cat` WHERE `id`=$p AND `status`=1"); $pq = mysqli_fetch_array($pquery);
	if ($pq != null) {
		$title = $pq['name'];
	} else {
		$title = "404";
	}
	require './theme/header.php';
	if ($pq != null) {
		require './system/cat.php';
	} else {
		require './system/404.php';
	}
	require './theme/footer.php';
} else {
	$title = "404";
	require './theme/header.php';
	require './system/404.php';
	require './theme/footer.php';
}
?>
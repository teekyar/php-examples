<?php  require './include/functions.php';
define('pactive', '');
//System
if (empty($_REQUEST['q'])) {
    exit(redirect('/'));
} else {
	$q= clean($_REQUEST['q']);
}
//Get Content

$squery = mysqli_query($conn, "SELECT * FROM `news` WHERE `desc` LIKE '%".$q."%';"); $sq = mysqli_fetch_array($squery);
if ($sq != null) {
	$title = 'نتایج جستجو برای '.$sq['name'];
} else {
	$title = "404";
}
require './theme/header.php';
if ($sq != null) {
	require './system/search.php';
} else {
	require './system/404.php';
}
require './theme/footer.php';

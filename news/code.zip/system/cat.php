<?php if (!defined('pactive')) {
	include '../include/functions.php'; header('Location: '.$su); exit;
} ?>


<!-- Breadcrumbs -->
<div class="container">
	<ul class="breadcrumbs">
		<li class="breadcrumbs__item">
			<a href="/" class="breadcrumbs__url">خانه</a>
		</li>
		<li class="breadcrumbs__item breadcrumbs__item--current">
			<?php echo $pq['name']; ?>
		</li>
	</ul>
</div>


<div class="main-container container" id="main-container">

	<!-- Content -->
	<div class="row">

		<!-- Posts -->
		<div class="col-lg-8 blog__content mb-72">
			<h1 class="page-title"><?php echo $pq['name']; ?></h1>

			<div class="row card-row">
				<?php
				$catpquery = mysqli_query($conn, "SELECT * FROM `news` WHERE `status`=1");
				while ($cpq = mysqli_fetch_assoc($catpquery)) {
					$catid = explode(' ', $cpq['catid']);
					if (in_array($pq['id'], $catid)) {
						?>
						<div class="col-md-6">
							<article class="entry card">
								<div class="entry__img-holder card__img-holder">
									<a href="<?php echo $su; ?>?get=news&p=<?php echo $cpq['id']; ?>">
										<div class="thumb-container thumb-70">
											<img data-src="<?php echo $cpq['image']; ?>" src="<?php echo $su; ?>img/empty.png" class="entry__img lazyload" alt="<?php echo $cpq['name']; ?>" />
										</div>
									</a>
								</div>

								<div class="entry__body card__body">
									<div class="entry__header">

										<h2 class="entry__title">
											<a href="<?php echo $su; ?>?get=news&p=<?php echo $cpq['id']; ?>"><?php echo $cpq['name']; ?></a>
										</h2>
										<ul class="entry__meta">
											<li class="entry__meta-author">
												<span>نویسنده:</span>
												<?php $caquery = mysqli_query($conn, "Select * From `admin` Where `id`=".$cpq['by']);
												$caq = mysqli_fetch_array($caquery); ?>
												<a href="<?php echo $su; ?>?get=author&p=<?php echo $caq['id']; ?>"><?php echo $caq['name']; ?></a>
											</li>
											<li class="entry__meta-date">
												<?php echo $cpq['date']; ?>
											</li>
										</ul>
									</div>
									<div class="entry__excerpt">
										<p>
											<?php echo $cpq['leader']; ?>
										</p>
									</div>
								</div>
							</article>
						</div>
						<?php
					}} ?>
			</div>

			<!-- Pagination -->
			<nav class="pagination">
				<span class="pagination__page pagination__page--current">۱</span>
				<a href="#" class="pagination__page">۲</a>
				<a href="#" class="pagination__page">۳</a>
				<a href="#" class="pagination__page">۴</a>
				<a href="#" class="pagination__page pagination__icon pagination__page--next"><i class="ui-arrow-left"></i></a>
			</nav>
		</div>
		<!-- end posts -->

		<?php require 'theme/sidebar.php'; ?>

	</div>
	<!-- end content -->
</div>
<!-- end main container -->
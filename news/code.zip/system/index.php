<?php if(!defined('pactive')){include '../include/functions.php';header('Location: '.$su);exit;} ?>



        <!-- Trending Now -->
        <div class="container">
            <div class="trending-now">
                <span class="trending-now__label">
                    <i class="ui-flash"></i>
                    خبرهای داغ</span>
                <div class="newsticker">
                    <ul class="newsticker__list">
                        <?php $hotnquery=mysqli_query($conn,"SELECT * FROM `news` WHERE `status`=1 AND `type`=3");
                        while($hnq=mysqli_fetch_array($hotnquery)){ ?>
                        <li class="newsticker__item"><a href="<?php echo $su."?get=news&p".$hnq['id']; ?>" class="newsticker__item-url"><?php echo $hnq['name']; ?></a></li>
                        <?php } ?>
                    </ul>
                </div>
                <div class="newsticker-buttons">
                    <button class="newsticker-button newsticker-button--next" id="newsticker-button--next" aria-label="previous article"><i class="ui-arrow-left"></i></button>
                    <button class="newsticker-button newsticker-button--prev" id="newsticker-button--prev" aria-label="next article"><i class="ui-arrow-right"></i></button>
                </div>
            </div>
        </div>

        <!-- Featured Posts Grid -->
        <section class="featured-posts-grid">
            <div class="container">
                <div class="row row-8">

                    <div class="col-lg-6">

                        <!-- Small post -->
                        <div class="featured-posts-grid__item featured-posts-grid__item--sm">
                            <?php $bestpquery=mysqli_query($conn,"SELECT * FROM `news` WHERE `status`=1 ORDER BY `news`.`id` DESC LIMIT 1");
                            if($bpq=mysqli_fetch_array($bestpquery)){ ?>
                            <article class="entry card post-list featured-posts-grid__entry">
                                <div class="entry__img-holder post-list__img-holder card__img-holder" style="background-image: url(<?php echo $bpq['image']; ?>)">
                                    <a href="<?php echo $su."?get=news&p=".$bpq['id']; ?>" class="thumb-url"></a>
                                    <img src="<?php echo $bpq['image']; ?>" alt="<?php echo $bpq['name']; ?>" class="entry__img d-none">
                                </div>

                                <div class="entry__body post-list__body card__body">
                                    <h2 class="entry__title">
                                        <a href="<?php echo $su."?get=news&p=".$bpq['id']; ?>"><?php echo $bpq['name']; ?></a>
                                    </h2>
                                    <ul class="entry__meta">
                                        <li class="entry__meta-author">
                                            <span>نویسنده:</span>
                                            <?php $pauthorquery=mysqli_query($conn,"SELECT * FROM `admin` WHERE `id`=".$bpq['by']);$paq=mysqli_fetch_array($pauthorquery); ?>
                                            <a href="#"><?php echo $paq['name']; ?></a>
                                        </li>
                                        <li class="entry__meta-date">
                                        <?php echo $bpq['date']; ?>
                                        </li>
                                    </ul>
                                </div>
                            </article>
                            <?php } ?>
                        </div> <!-- end post -->

                        <!-- Small post -->
                        <div class="featured-posts-grid__item featured-posts-grid__item--sm">
                            <?php $recpquery=mysqli_query($conn,"SELECT * FROM `news` WHERE `status`=1 AND `type`=1 ORDER BY `news`.`id` DESC LIMIT 1");
                            if($rpq=mysqli_fetch_array($recpquery)){ ?>
                            <article class="entry card post-list featured-posts-grid__entry">
                                <div class="entry__img-holder post-list__img-holder card__img-holder" style="background-image: url(<?php echo $rpq['image']; ?>)">
                                    <a href="<?php echo $su."?get=news&p=".$rpq['id']; ?>" class="thumb-url"></a>
                                    <img src="<?php echo $rpq['image']; ?>" alt="<?php echo $rpq['name']; ?>" class="entry__img d-none">
                                </div>

                                <div class="entry__body post-list__body card__body">
                                    <h2 class="entry__title">
                                    <a href="<?php echo $su."?get=news&p=".$rpq['id']; ?>"><?php echo $rpq['name']; ?></a>
                                    </h2>
                                    <ul class="entry__meta">
                                        <li class="entry__meta-author">
                                            <span>نویسنده:</span>
                                            <?php $pauthorquery=mysqli_query($conn,"SELECT * FROM `admin` WHERE `id`=".$rpq['by']);$paq=mysqli_fetch_array($pauthorquery); ?>
                                            <a href="#"><?php echo $paq['name']; ?></a>
                                        </li>
                                        <li class="entry__meta-date">
                                        <?php echo $rpq['date']; ?>
                                        </li>
                                    </ul>
                                </div>
                            </article>
                            <?php } ?>
                        </div> <!-- end post -->

                        <!-- Small post -->
                        <div class="featured-posts-grid__item featured-posts-grid__item--sm">
                            <?php $npquery=mysqli_query($conn,"SELECT * FROM `news` WHERE `status`=1 AND `type`=4 ORDER BY `news`.`id` DESC LIMIT 1");
                            if($npq=mysqli_fetch_array($npquery)){ ?>
                            <article class="entry card post-list featured-posts-grid__entry">
                                <div class="entry__img-holder post-list__img-holder card__img-holder" style="background-image: url(<?php echo $npq['image']; ?>)">
                                    <a href="<?php echo $su."?get=news&p=".$npq['id']; ?>" class="thumb-url"></a>
                                    <img src="<?php echo $npq['image']; ?>" alt="<?php echo $npq['name']; ?>" class="entry__img d-none">
                                </div>

                                <div class="entry__body post-list__body card__body">
                                    <h2 class="entry__title">
                                        <a href="<?php echo $su."?get=news&p=".$npq['id']; ?>"><?php echo $npq['name']; ?></a>
                                    </h2>
                                    <ul class="entry__meta">
                                        <li class="entry__meta-author">
                                            <span>نویسنده:</span>
                                            <?php $pauthorquery=mysqli_query($conn,"SELECT * FROM `admin` WHERE `id`=".$npq['by']);$paq=mysqli_fetch_array($pauthorquery); ?>
                                            <a href="#"><?php echo $paq['name']; ?></a>
                                        </li>
                                        <li class="entry__meta-date">
                                            <?php echo $npq['date']; ?>
                                        </li>
                                    </ul>
                                </div>
                            </article>
                            <?php } ?>
                        </div> <!-- end post -->

                    </div> <!-- end col -->

                    <div class="col-lg-6">

                        <!-- Large post -->
                        <div class="featured-posts-grid__item featured-posts-grid__item--lg">
                            <?php $spquery=mysqli_query($conn,"SELECT * FROM `news` WHERE `status`=1 AND `type`=2 ORDER BY `news`.`id` DESC LIMIT 1");
                            if($spq=mysqli_fetch_array($spquery)){ ?>
                            <article class="entry card featured-posts-grid__entry">
                                <div class="entry__img-holder card__img-holder">
                                    <a href="<?php echo $su."?get=news&p=".$spq['id']; ?>">
                                        <img src="<?php echo $spq['image']; ?>" alt="<?php echo $spq['name']; ?>" class="entry__img">
                                    </a>
                                </div>

                                <div class="entry__body card__body">
                                    <h2 class="entry__title">
                                        <a href="<?php echo $su."?get=news&p=".$spq['id']; ?>"><?php echo $spq['name']; ?></a>
                                    </h2>
                                    <ul class="entry__meta">
                                        <li class="entry__meta-author">
                                            <span>نویسنده:</span>
                                            <?php $pauthorquery=mysqli_query($conn,"SELECT * FROM `admin` WHERE `id`=".$spq['by']);$paq=mysqli_fetch_array($pauthorquery); ?>
                                            <a href="#"><?php echo $paq['name']; ?></a>
                                        </li>
                                        <li class="entry__meta-date">
                                            <?php echo $spq['date']; ?>
                                        </li>
                                    </ul>
                                </div>
                            </article>
                            <?php } ?>
                        </div> <!-- end large post -->
                    </div>

                </div>
            </div>
        </section> <!-- end featured posts grid -->

        <div class="main-container container pt-24" id="main-container">

            <!-- Carousel posts -->
            <section class="section mb-0">
                <div class="title-wrap title-wrap--line">
                    <h3 class="section-title">پربازدیدترین مقالات</h3>
                </div>

                <!-- Slider -->
                <div id="owl-posts" class="owl-carousel owl-theme owl-carousel--arrows-outside">
                    <?php $hpquery=mysqli_query($conn,"SELECT * FROM `news` WHERE `status`=1 ORDER BY `news`.`hit` DESC LIMIT 5");
                    while($hpq=mysqli_fetch_array($hpquery)){ ?>
                    <article class="entry thumb thumb--size-1">
                        <div class="entry__img-holder thumb__img-holder" style="background-image: url('<?php echo $hpq['image']; ?>');">
                            <div class="bottom-gradient"></div>
                            <div class="thumb-text-holder">
                                <h2 class="thumb-entry-title">
                                    <a href="<?php echo $su."?get=news&p=".$hpq['id']; ?>"><?php echo $hpq['name']; ?></a>
                                </h2>
                            </div>
                            <a href="<?php echo $su."?get=news&p=".$hpq['id']; ?>" class="thumb-url"></a>
                        </div>
                    </article>
                    <?php } ?>
                </div> <!-- end slider -->

            </section> <!-- end carousel posts -->


            <!-- Posts from categories -->
            <section class="section mb-0">
                <div class="row">

                    <?php $cat=mysqli_query($conn,"SELECT * FROM `cat` WHERE `status`=1");
                    while($cq=mysqli_fetch_array($cat)){ ?>
                    <!-- PCAT -->
                    <div class="col-md-6">
                        <div class="title-wrap title-wrap--line">
                            <h3 class="section-title"><?php echo $cq['name']; ?></h3>
                        </div>
                        <div class="row">
                            <div class="col-lg-6">
                                <?php $tcpquery=mysqli_query($conn,"SELECT * FROM `news` ORDER BY `news`.`hit` DESC");
                                while($tcpq=mysqli_fetch_array($tcpquery)){
                                $tcatid=explode(" ",$tcpq['catid']);
                                $t=0;
                                if(in_array($cq['id'],$tcatid)){ ?>
                                <article class="entry thumb thumb--size-2">
                                    <div class="entry__img-holder thumb__img-holder" style="background-image: url('<?php echo $tcpq['image']; ?>');">
                                        <div class="bottom-gradient"></div>
                                        <div class="thumb-text-holder thumb-text-holder--1">
                                            <h2 class="thumb-entry-title">
                                                <a href="<?php echo $su."?get=news&p=".$tcpq['id']; ?>"><?php echo $tcpq['name']; ?></a>
                                            </h2>
                                            <ul class="entry__meta">
                                                <li class="entry__meta-author">
                                                    <span>نویسنده:</span>
                                                    <?php $pauthorquery=mysqli_query($conn,"SELECT * FROM `admin` WHERE `id`=".$tcpq['by']);$paq=mysqli_fetch_array($pauthorquery); ?>
                                                    <a href="#"><?php echo $paq['name']; ?></a>
                                                </li>
                                                <li class="entry__meta-date">
                                                    <?php echo $tcpq['date']; ?>
                                                </li>
                                            </ul>
                                        </div>
                                        <a href="<?php echo $su."?get=news&p=".$tcpq['id']; ?>" class="thumb-url"></a>
                                    </div>
                                </article>
                                <?php ++$t;}if($t == 1){break;}} ?>
                            </div>
                            <div class="col-lg-6">
                                <ul class="post-list-small post-list-small--dividers post-list-small--arrows mb-24">
                                    <?php $catposts=mysqli_query($conn,"SELECT * FROM `news` ORDER BY `news`.`id` DESC");
                                    $i=0;
                                    while($cp=mysqli_fetch_array($catposts)){
                                    $catid=explode(" ",$cp['catid']);
                                    if(in_array($cq['id'],$catid)){ ?>
                                    <li class="post-list-small__item">
                                        <article class="post-list-small__entry">
                                            <div class="post-list-small__body">
                                                <h3 class="post-list-small__entry-title">
                                                    <a href="<?php echo $su."?get=news&p=".$cp['id']; ?>"><?php echo $cp['name']; ?></a>
                                                </h3>
                                            </div>
                                        </article>
                                    </li>
                                    <?php ++$i;}if($i == 5){break;}} ?>
                                </ul>
                            </div>
                        </div>
                    </div> <!-- end pcat -->
                    <?php } ?>

                </div>
            </section> <!-- end posts from categories -->

            <!-- Content Secondary -->
            <div class="row">

                <!-- Posts -->
                <div class="col-lg-8 blog__content mb-72">

                    <section class="section">
                        <div class="title-wrap title-wrap--line">
                            <h3 class="section-title">آخرین اخبار</h3>
                            <a href="#" class="all-posts-url">نمایش همه</a>
                        </div>
                        
                        <?php $lasposts=mysqli_query($conn,"SELECT * FROM `news` ORDER BY `news`.`id` DESC LIMIT 6");
                        while($lp=mysqli_fetch_array($lasposts)){ ?>
                        <article class="entry card post-list">
                            <div class="entry__img-holder post-list__img-holder card__img-holder" style="background-image: url(<?php echo $lp['image']; ?>)">
                                <a href="<?php echo $su."?get=news&p=".$lp['id']; ?>" class="thumb-url"></a>
                                <img src="<?php echo $lp['image']; ?>" alt="<?php echo $lp['name']; ?>" class="entry__img d-none">
                            </div>

                            <div class="entry__body post-list__body card__body">
                                <div class="entry__header">
                                    <h2 class="entry__title">
                                        <a href="<?php echo $su."?get=news&p=".$lp['id']; ?>"><?php echo $lp['name']; ?></a>
                                    </h2>
                                    <ul class="entry__meta">
                                        <li class="entry__meta-author">
                                            <span>نویسنده:</span>
                                            <a href="#">بهرامی راد</a>
                                        </li>
                                        <li class="entry__meta-date">
                                            <?php echo $lp['date']; ?>
                                        </li>
                                    </ul>
                                </div>
                                <div class="entry__excerpt">
                                    <p><?php echo $lp['leader']; ?>...</p>
                                </div>
                            </div>
                        </article>
                        <?php } ?>
                    </section> <!-- end worldwide news -->

                    <!-- Pagination -->
                    <nav class="pagination">
                        <span class="pagination__page pagination__page--current">۱</span>
                        <a href="#" class="pagination__page">۲</a>
                        <a href="#" class="pagination__page">۳</a>
                        <a href="#" class="pagination__page">۴</a>
                        <a href="#" class="pagination__page pagination__icon pagination__page--next"><i class="ui-arrow-left"></i></a>
                    </nav>

                </div> <!-- end posts -->

                <!-- Sidebar 1 -->
                <aside class="col-lg-4 sidebar sidebar--1 sidebar--right">

                    <!-- Widget Categories -->
                    <aside class="widget widget_categories">
                        <h4 class="widget-title">موضوعات</h4>
                        <ul>
                            <?php $catsquery=mysqli_query($conn,"SELECT * FROM `cat` WHERE `status`=1");
                            while($csq=mysqli_fetch_array($catsquery)){ ?>
                            <li><a href="<?php echo $su."?get=news&p=".$csq['id']; ?>"><?php echo $csq['name']; ?> <span class="categories-count">-</span></a></li>
                            <?php } ?>
                        </ul>
                    </aside> <!-- end widget categories -->

                    <!-- Widget Recommended (Rating) -->
                    <aside class="widget widget-rating-posts">
                        <h4 class="widget-title">اخبار منتخب</h4>
                        <?php $rpquery=mysqli_query($conn,"SELECT * FROM `news` WHERE `status`=1 AND `type`=2 ORDER BY `news`.`id` DESC LIMIT 2");
                        while($rpq=mysqli_fetch_array($rpquery)){ ?>
                        <article class="entry">
                            <div class="entry__img-holder">
                                <a href="<?php echo $su."?get=news&p".$rpq['id']; ?>">
                                    <div class="thumb-container thumb-60">
                                        <img data-src="<?php echo $rpq['image']; ?>" src="<?php echo $su; ?>img/empty.png" class="entry__img lazyload" alt="<?php echo $rpq['name']; ?>">
                                    </div>
                                </a>
                            </div>

                            <div class="entry__body">
                                <div class="entry__header">

                                    <h2 class="entry__title">
                                        <a href="<?php echo $su."?get=news&p".$rpq['id']; ?>"><?php echo $rpq['name']; ?></a>
                                    </h2>
                                    <ul class="entry__meta">
                                        <li class="entry__meta-author">
                                            <span>نویسنده:</span>
                                            <?php $pauthorquery=mysqli_query($conn,"SELECT * FROM `admin` WHERE `id`=".$rpq['by']);$paq=mysqli_fetch_array($pauthorquery); ?>
                                            <a href="#"><?php echo $paq['name']; ?></a>
                                        </li>
                                        <li class="entry__meta-date">
                                            <?php echo $rpq['date']; ?>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </article>
                        <?php } ?>
                    </aside> <!-- end widget recommended (rating) -->
                </aside> <!-- end sidebar 1 -->
            </div> <!-- content secondary -->


        </div> <!-- end main container -->



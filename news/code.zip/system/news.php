<?php if(!defined('pactive')){include '../include/functions.php';header('Location: '.$su);exit;} ?>

        <!-- Breadcrumbs -->
        <div class="container">
            <ul class="breadcrumbs">
                <li class="breadcrumbs__item">
                    <a href="/" class="breadcrumbs__url">خانه</a>
                </li>
                <li class="breadcrumbs__item breadcrumbs__item--current">
                    <?php echo $pq['name'] ?>
                </li>
            </ul>
        </div>

        <div class="main-container container" id="main-container">

            <!-- Content -->
            <div class="row">

                <!-- post content -->
                <div class="col-lg-8 blog__content mb-72">
                    <div class="content-box">

                        <!-- standard post -->
                        <article class="entry mb-0">

                            <div class="single-post__entry-header entry__header">
                                <?php $pcatquery=mysqli_query($conn, "SELECT * FROM `cat` WHERE `status`=1");
                                while($pcq=mysqli_fetch_array($pcatquery)){
                                $pcat=explode(" ",$pq['catid']);
                                if(in_array($pcq['id'],$pcat)){ ?>
                                <a href="<?php echo $su."?get=cat&p=".$pcq['id']; ?>" class="entry__meta-category entry__meta-category--label entry__meta-category--green"><?php echo $pcq['name']; ?></a>
                                <?php }} ?>
                                <h1 class="single-post__entry-title">
                                    <?php echo $pq['name'] ?>
                                </h1>

                                <div class="entry__meta-holder">
                                    <ul class="entry__meta">
                                        <li class="entry__meta-author">
                                            <span>نویسنده:</span>
                                            <a href="javascript:void(0)"><?php $pauthorquery=mysqli_query($conn,"SELECT * FROM `admin` WHERE `id`=".$pq['by']);$paq=mysqli_fetch_array($pauthorquery); echo $paq['name']; ?></a>
                                        </li>
                                        <li class="entry__meta-date">
                                        <?php echo $pq['date']; ?>
                                        </li>
                                    </ul>

                                    <ul class="entry__meta">
                                        <li class="entry__meta-views">
                                            <i class="ui-eye"></i>
                                            <?php $phit=++$pq['hit']; $pid=$pq['id']; $phitquery=mysqli_query($conn,"UPDATE `news` SET `hit` = '$phit' WHERE `news`.`id` = $pid;"); ?>
                                            <span><?php echo $pq['hit']; ?></span>
                                        </li>
                                        <li class="entry__meta-comments">
                                            <a href="javascript:void(0)">
                                                <i class="ui-chat-empty"></i><?php echo mysqli_num_rows(mysqli_query($conn,'SELECT `id` FROM `comment` WHERE `pid`='.$pq['id'].' AND `status`=1;')); ?>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div> <!-- end entry header -->

                            <div class="entry__img-holder">
                                <img src="<?php echo $pq['image']; ?>" alt="<?php echo $pq['name']; ?>" class="entry__img">
                            </div>

                            <div class="entry__article-wrap">

                                <!-- Share -->
                                <div class="entry__share">
                                    <div class="sticky-col">
                                        <div class="socials socials--rounded socials--large">
                                            <a class="social social-facebook" href="javascript:void(0)" title="facebook" target="_blank" aria-label="facebook">
                                                <i class="ui-facebook"></i>
                                            </a>
                                            <a class="social social-twitter" href="javascript:void(0)" title="twitter" target="_blank" aria-label="twitter">
                                                <i class="ui-twitter"></i>
                                            </a>
                                            <a class="social social-google-plus" href="javascript:void(0)" title="google" target="_blank" aria-label="google">
                                                <i class="ui-google"></i>
                                            </a>
                                            <a class="social social-pinterest" href="javascript:void(0)" title="pinterest" target="_blank" aria-label="pinterest">
                                                <i class="ui-pinterest"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div> <!-- share -->

                                <div class="entry__article">
                                    <?php echo $pq['desc']; ?>
                                    <!-- tags -->
                                    <div class="entry__tags">
                                        <i class="ui-tags"></i>
                                        <span class="entry__tags-label">برچسب ها:</span>
                                        <?php $ptag=explode(" ",$pq['tags']);
                                        foreach($ptag as $tarray){ ?>
                                        <a href="#" rel="tag"><?php echo $tarray; ?></a>
                                        <?php } ?>
                                    </div> <!-- end tags -->

                                </div> <!-- end entry article -->
                            </div> <!-- end entry article wrap -->

                            <!-- Author -->
                            <div class="entry-author clearfix">
                                <img alt="<?php echo $paq['name']; ?>" data-src="<?php echo $su; ?>img/default-avatar.png" src="<?php echo $su; ?>img/empty.png" class="avatar lazyload">
                                <div class="entry-author__info">
                                    <h6 class="entry-author__name">
                                        <a href="javascript:void(0)"><?php echo $paq['name']; ?></a>
                                    </h6>
                                    <p class="mb-0"><?php echo $paq['about']; ?></p>
                                </div>
                            </div>

                            <!-- Related Posts -->
                            <section class="section related-posts mt-40 mb-0">
                                <div class="title-wrap title-wrap--line">
                                    <h3 class="section-title">مطالب مرتبط</h3>
                                </div>

                                <!-- Slider -->
                                <div id="owl-posts-3-items" class="owl-carousel owl-theme owl-carousel--arrows-outside">
                                    <?php $prquery=mysqli_query($conn,"SELECT * FROM `news` WHERE `status`=1");
                                    while($prq=mysqli_fetch_assoc($prquery)){
                                    $pr=explode(" ",$prq['catid']);
                                    $pc=explode(" ",$pq['catid']);
                                    if(in_array($pc[1],$pr)){?>
                                    <article class="entry thumb thumb--size-1">
                                        <div class="entry__img-holder thumb__img-holder" style="background-image: url('<?php echo $prq['image']; ?>');">
                                            <div class="bottom-gradient"></div>
                                            <div class="thumb-text-holder">
                                                <h2 class="thumb-entry-title">
                                                    <a href="<?php echo $su."?get=news&p".$prq['id']; ?>"><?php echo $prq['name']; ?></a>
                                                </h2>
                                            </div>
                                            <a href="<?php echo $su."?get=news&p".$prq['id']; ?>" class="thumb-url"></a>
                                        </div>
                                    </article>
                                    <?php }} ?>
                                </div> <!-- end slider -->

                            </section> <!-- end related posts -->

                        </article> <!-- end standard post -->

                        <!-- Comments -->
                        <div class="entry-comments">
                            <div class="title-wrap title-wrap--line">
                                <h3 class="section-title"><?php echo mysqli_num_rows(mysqli_query($conn,'SELECT `id` FROM `comment` WHERE `pid`='.$pq['id'].' AND `status`=1;')); ?> دیدگاه</h3>
                            </div>
                            <ul class="comment-list">
                                <?php $pcommentquery=mysqli_query($conn,"SELECT * FROM `comment` WHERE `pid`=".$pq['id']." AND `type`=1 AND `status`=1;");
                                while($pctq=mysqli_fetch_array($pcommentquery)){ ?>
                                <li class="comment">
                                    <div class="comment-body">
                                        <div class="comment-avatar">
                                            <img alt="<?php echo $pctq['uname']; ?>" src="<?php echo $su; ?>img/default-avatar.png">
                                        </div>
                                        <div class="comment-text">
                                            <h6 class="comment-author"><?php echo $pctq['uname']; ?></h6>
                                            <div class="comment-metadata">
                                                <a href="javascript:alert('تاریخ ارسال نظر')" class="comment-date"><?php echo jdate('Y-m-d',$pctq['cdate']); ?></a>
                                            </div>
                                            <p><?php echo $pctq['msg']; ?></p>
                                            <a href="javascript:alert('شرمنده!\nاین ویژگی در دسترس نیست!')" class="comment-reply">پاسخ</a>
                                        </div>
                                    </div>
                                    <?php if($pctq['aid']!=null){
                                    $pctaquery=mysqli_query($conn,'SELECT * FROM `comment` WHERE `id`='.$pctq['aid'].' AND `aid` IS NULL AND `type`=2 AND `status`=1;');
                                    if($pctaquery){
                                    $pctaq=mysqli_fetch_array($pctaquery); ?>
                                    <ul class="children">
                                        <li class="comment">
                                            <div class="comment-body">
                                                <div class="comment-avatar">
                                                    <img alt="<?php echo $pctaq['uname']; ?>" src="<?php echo $su; ?>img/default-avatar.png">
                                                </div>
                                                <div class="comment-text">
                                                    <h6 class="comment-author">در پاسخ به <?php echo $pctq['uname']; ?></h6>
                                                    <div class="comment-metadata">
                                                        <a href="javascript:alert('تاریخ ارسال نظر')" class="comment-date"><?php echo jdate('Y-m-d',$pctaq['cdate']); ?></a>
                                                    </div>
                                                    <p><?php echo $pctaq['msg']; ?></p>
                                                    <a href="javascript:alert('به پاسخ یک نظر نمیتوان پاسخ داد!')" class="comment-reply">پاسخ</a>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                    <?php }} ?>
                                </li>
                                <?php } ?>
                            </ul>
                        </div> <!-- end comments -->

                        <!-- Comment Form -->
                        <div id="respond" class="comment-respond">
                            <div class="title-wrap">
                                <h5 class="comment-respond__title section-title">دیدگاه شما</h5>
                            </div>
                            <?php
                            if($_POST['submit']){
                                if(!empty($_POST['name']) && !empty($_POST['email']) && !empty($_POST['website']) && !empty($_POST['comment'])){ 
                                    if(preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix", $_POST['email'])){
                                        $name=clean($_POST['name']);
                                        $website=str_replace('http','',str_replace('https','',clean($_POST['website'])));
                                        $comment=clean($_POST['comment']);
                                        if(mysqli_query($conn,'INSERT INTO `comment` (`pid`,`uname`,`umail`,`uwebsite`,`msg`,`cdate`,`type`,`status`) VALUES ('.$pq['id'].',"'.$name.'","'.$_POST['email'].'","'.$website.'","'.$comment.'",'.time().',1,2);')){
                                            echo warn('نظر شما با موفقیت ارسال شد!');
                                        }else{
                                            echo warn('مشکلی در اجرای عملیات پیش آمد!');
                                        }
                                    }else{
                                        echo warn('ایمیل وارد شده صحیح نمی باشد!');
                                    }
                                }else{
                                    warn('تکمیل تمامی فیلد ها الزامیست!');
                                }
                            } ?>
                            <form id="form" class="comment-form" method="post" action="">
                                <p class="comment-form-comment">
                                    <label for="comment">دیدگاه</label>
                                    <textarea id="comment" name="comment" rows="5" required="required"></textarea>
                                </p>

                                <div class="row row-20">
                                    <div class="col-lg-4">
                                        <label for="name">نام: *</label>
                                        <input name="name" id="name" type="text">
                                    </div>
                                    <div class="col-lg-4">
                                        <label for="comment">ایمیل: *</label>
                                        <input name="email" id="email" type="email">
                                    </div>
                                    <div class="col-lg-4">
                                        <label for="comment">وبسایت:</label>
                                        <input name="website" id="website" type="text">
                                    </div>
                                </div>

                                <p class="comment-form-submit">
                                    <input type="submit" class="btn btn-lg btn-color btn-button" value="ارسال دیدگاه" name="submit" id="submit-message">
                                </p>

                            </form>
                        </div> <!-- end comment form -->

                    </div> <!-- end content box -->
                </div> <!-- end post content -->

                <?php require 'theme/sidebar.php'; ?>

            </div> <!-- end content -->
        </div> <!-- end main container -->

<?php if(!defined('pactive')){include '../include/functions.php';header('Location: '.$su);exit;} ?>
        <!-- Footer -->
        <footer class="footer footer--light">
            <p style="text-align: center;">تمامی حقوق محفوط است.</p>
        </footer> <!-- end footer -->

        <div id="back-to-top">
            <a href="#top" aria-label="Go to top"><i class="ui-arrow-up"></i></a>
        </div>

    </main> <!-- end main-wrapper -->


    <!-- jQuery Scripts -->
    <script src="<?php echo $su; ?>js/jquery.min.js"></script>
    <script src="<?php echo $su; ?>js/bootstrap.min.js"></script>
    <script src="<?php echo $su; ?>js/easing.min.js"></script>
    <script src="<?php echo $su; ?>js/owl-carousel.min.js"></script>
    <script src="<?php echo $su; ?>js/flickity.pkgd.min.js"></script>
    <script src="<?php echo $su; ?>js/twitterFetcher_min.js"></script>
    <script src="<?php echo $su; ?>js/jquery.newsTicker.min.js"></script>
    <script src="<?php echo $su; ?>js/modernizr.min.js"></script>
    <script src="<?php echo $su; ?>js/scripts.js"></script>

</body>

</html>
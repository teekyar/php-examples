<?php if(!defined('pactive')){include '../include/functions.php';header('Location: '.$su);exit;} ?>
                <!-- Sidebar -->
                <aside class="col-lg-4 sidebar sidebar--right">

                    <!-- Widget Popular Posts -->
                    <aside class="widget widget-popular-posts">
                        <h4 class="widget-title">اخبار پیشنهادی</h4>
                        <ul class="post-list-small">
                            <?php $recpq=mysqli_query($conn,"SELECT * FROM `news` WHERE `status`=1 AND `type`=1 ORDER BY `id` DESC LIMIT 6");
                            while($rcpq=mysqli_fetch_array($recpq)){ ?>
                            <li class="post-list-small__item">
                                <article class="post-list-small__entry clearfix">
                                    <div class="post-list-small__img-holder">
                                        <div class="thumb-container thumb-100">
                                            <a href="<?php echo $su."?get=news&p=".$rcpq['id']; ?>">
                                                <img data-src="<?php echo $rcpq['image']; ?>" src="<?php echo $su; ?>img/empty.png" alt="<?php echo $rcpq['name']; ?>" class="post-list-small__img--rounded lazyload">
                                            </a>
                                        </div>
                                    </div>
                                    <div class="post-list-small__body">
                                        <h3 class="post-list-small__entry-title">
                                            <a href="<?php echo $su."?get=news&p=".$rcpq['id']; ?>"><?php echo $rcpq['name']; ?></a>
                                        </h3>
                                        <ul class="entry__meta">
                                            <li class="entry__meta-author">
                                                <span>نویسنده:</span>
                                                <?php $pauthorquery=mysqli_query($conn,"SELECT * FROM `admin` WHERE `id`=".$rcpq['by']);$paq=mysqli_fetch_array($pauthorquery); ?>
                                                <a href="#"><?php echo $paq['name']; ?></a>
                                            </li>
                                            <li class="entry__meta-date">
                                                <?php echo $rcpq['date']; ?>
                                            </li>
                                        </ul>
                                    </div>
                                </article>
                            </li>
                            <?php } ?>
                        </ul>
                    </aside> <!-- end widget popular posts -->

                    <!-- Widget Newsletter -->
                    <aside class="widget widget_mc4wp_form_widget">
                        <h4 class="widget-title">خبرنامه</h4>
                        <p class="newsletter__text">
                            <i class="ui-email newsletter__icon"></i>
                            برای اطلاع از آخرین خبرها مشترک شوید
                        </p>
                        <form class="mc4wp-form" method="post">
                            <div class="mc4wp-form-fields">
                                <div class="form-group">
                                    <input type="email" name="EMAIL" placeholder="ایمیل" required="">
                                </div>
                                <div class="form-group">
                                    <input type="submit" class="btn btn-lg btn-color" value="عضویت">
                                </div>
                            </div>
                        </form>
                    </aside> <!-- end widget newsletter -->


                </aside> <!-- end sidebar -->
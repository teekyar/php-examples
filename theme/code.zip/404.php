<?php $ptitle="یافت نشد";
define('fileactive','');
require 'include/header.php'; ?>

        <div class="main-container container pt-80 pb-80" id="main-container">
            <!-- post content -->
            <div class="blog__content mb-72">
                <div class="container text-center">
                    <h1 class="page-404-number">404</h1>
                    <h2>صفحه یافت نشد</h2>
                    <p>نگران نباشید.جستجو کنید...</p>

                    <div class="row justify-content-center mt-40">

                        <div class="col-md-6">
                            <!-- Search form -->
                            <form role="search" method="get" class="search-form relative">
                                <input type="search" class="widget-search-input mb-0" placeholder="جستجو مقاله">
                                <button type="submit" class="widget-search-button btn btn-color"><i class="ui-search widget-search-icon"></i></button>
                            </form>
                        </div>

                    </div> <!-- end row -->

                </div> <!-- end container -->
            </div> <!-- end post content -->
        </div> <!-- end main container -->

<?php require 'include/footer.php'; ?>
<?php $ptitle="تماس باما";
define('fileactive','');
require 'include/header.php'; ?>

        <!-- Breadcrumbs -->
        <div class="container">
            <ul class="breadcrumbs">
                <li class="breadcrumbs__item">
                    <a href="/" class="breadcrumbs__url">خانه</a>
                </li>
                <li class="breadcrumbs__item breadcrumbs__item--current">
                    <?php echo $ptitle; ?>
                </li>
            </ul>
        </div>

        <div class="main-container container" id="main-container">
            <!-- post content -->
            <div class="blog__content mb-72">
                <h1 class="page-title"><?php echo $ptitle; ?></h1>

                <!-- Google Map -->
                <div id="google-map" class="gmap" data-address="V Tytana St, Manila, Philippines"></div>

                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <h4>با ما تماس بگیرید</h4>
                        <p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است.</p>
                        <ul class="contact-items">
                            <li class="contact-item">
                                <address>خراسان شمالی - بجنورد</address>
                            </li>
                            <li class="contact-item"><a href="#">۰۵۸-۳۲۲۲۲۲۲۲</a></li>
                            <li class="contact-item"><a href="mailto:topkala@gmail.com">topkalasupport@gmail.com</a></li>
                        </ul>

                        <!-- Contact Form -->
                        <form id="contact-form" class="contact-form mt-30 mb-30" method="post" action="#">
                            <div class="contact-name">
                                <label for="name">نام <abbr title="required" class="required">*</abbr></label>
                                <input name="name" id="name" type="text">
                            </div>
                            <div class="contact-email">
                                <label for="email">ایمیل <abbr title="required" class="required">*</abbr></label>
                                <input name="email" id="email" type="email">
                            </div>
                            <div class="contact-subject">
                                <label for="email">موضوع</label>
                                <input name="subject" id="subject" type="text">
                            </div>
                            <div class="contact-message">
                                <label for="message">پیام <abbr title="required" class="required">*</abbr></label>
                                <textarea id="message" name="message" rows="7" required="required"></textarea>
                            </div>

                            <input type="submit" class="btn btn-lg btn-color btn-button" value="فرستادن" id="submit-message">
                            <div id="msg" class="message"></div>
                        </form>

                    </div>
                </div>
            </div> <!-- end post content -->
        </div> <!-- end main container -->

<?php require 'include/footer.php'; ?>
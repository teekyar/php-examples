<?php if(!defined('fileactive')){header('Location: /');exit;} ?>
<!-- Comments -->
<div class="entry-comments">
                            <div class="title-wrap title-wrap--line">
                                <h3 class="section-title">۳ دیدگاه</h3>
                            </div>
                            <ul class="comment-list">
                                <li class="comment">
                                    <div class="comment-body">
                                        <div class="comment-avatar">
                                            <img alt="" src="img/default-avatar.png">
                                        </div>
                                        <div class="comment-text">
                                            <h6 class="comment-author">بهرامی راد</h6>
                                            <div class="comment-metadata">
                                                <a href="#" class="comment-date">۴ اردیبهشت ۱۳۹۸</a>
                                            </div>
                                            <p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است.</p>
                                            <a href="#" class="comment-reply">پاسخ</a>
                                        </div>
                                    </div>

                                    <ul class="children">
                                        <li class="comment">
                                            <div class="comment-body">
                                                <div class="comment-avatar">
                                                    <img alt="" src="img/default-avatar.png">
                                                </div>
                                                <div class="comment-text">
                                                    <h6 class="comment-author">حامد</h6>
                                                    <div class="comment-metadata">
                                                        <a href="#" class="comment-date">۴ اردیبهشت ۱۳۹۸</a>
                                                    </div>
                                                    <p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است.</p>
                                                    <a href="#" class="comment-reply">پاسخ</a>
                                                </div>
                                            </div>
                                        </li> <!-- end reply comment -->
                                    </ul>

                                </li> <!-- end 1-2 comment -->

                                <li>
                                    <div class="comment-body">
                                        <div class="comment-avatar">
                                            <img alt="" src="img/default-avatar.png">
                                        </div>
                                        <div class="comment-text">
                                            <h6 class="comment-author">علی</h6>
                                            <div class="comment-metadata">
                                                <a href="#" class="comment-date">۴ اردیبهشت ۱۳۹۸</a>
                                            </div>
                                            <p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است.</p>
                                            <a href="#" class="comment-reply">پاسخ</a>
                                        </div>
                                    </div>
                                </li> <!-- end 3 comment -->

                            </ul>
                        </div> <!-- end comments -->

                        <!-- Comment Form -->
                        <div id="respond" class="comment-respond">
                            <div class="title-wrap">
                                <h5 class="comment-respond__title section-title">دیدگاه شما</h5>
                            </div>
                            <form id="form" class="comment-form" method="post" action="#">
                                <p class="comment-form-comment">
                                    <label for="comment">دیدگاه</label>
                                    <textarea id="comment" name="comment" rows="5" required="required"></textarea>
                                </p>

                                <div class="row row-20">
                                    <div class="col-lg-4">
                                        <label for="name">نام: *</label>
                                        <input name="name" id="name" type="text">
                                    </div>
                                    <div class="col-lg-4">
                                        <label for="comment">ایمیل: *</label>
                                        <input name="email" id="email" type="email">
                                    </div>
                                    <div class="col-lg-4">
                                        <label for="comment">وبسایت:</label>
                                        <input name="website" id="website" type="text">
                                    </div>
                                </div>

                                <p class="comment-form-submit">
                                    <input type="submit" class="btn btn-lg btn-color btn-button" value="ارسال دیدگاه" id="submit-message">
                                </p>

                            </form>
                        </div> <!-- end comment form -->